<?php
include("PDO.php");

$bdd=getDatabase();
if (isset($_POST['email'])and isset($_POST['password'])) {
    $requete=$bdd->prepare('SELECT * FROM etudiants WHERE email = :email ');
    $requete->bindvalue(':email', $_POST['email'], PDO::PARAM_STR);
    $requete->execute();

 if ($donnee=$requete->fetch()) { // si tu trouves un resultat
        if ($donnee['password']==$_POST['password']) {
            session_start();
            $_SESSION['email']=$donnee['email'];
            $_SESSION['password'] = $donnee['password'];
            echo'Vous êtes connecté';
            header('location: homeConnect.html'); // A changer une fois la page de redirection créer
        } else {
            echo'Mot de passe incorrect <br> <a href="homeTest.html">Retour</a> ' ;
            header('url=connexionC.php'); // mauvais password
        }
    } else {
        echo ' Utilisateur incorrect <br> <a href="homeTest.html">Retour</a>';
        header('url=connexionC.php'); // utilisateur incorrect
    }
}

?>
