<!DOCTYPE html>
<html lang="en">
<head>
	<title>Annonces</title>
	<meta charset="UTF-8">
	<meta name="description" content="Labs - Design Studio">
	<meta name="keywords" content="lab, onepage, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,700|Roboto:300,400,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>

	<!-- Header section -->
	<header class="header-section">
		<div class="logo">
			<img src="logo/logo.png" alt=""><!-- Logo -->
		</div>
		<!-- Navigation -->
		<div class="responsive"><i class="fa fa-bars"></i></div>
		<nav>
			<ul class="menu-list">
				<li><a href="homeConnect.html">Home</a></li>
				<li class="active"><a href="annonce.php">Annonces</a></li>
				<li><a href="cours.php">Cours</a></li>
				<li><a href="formulaire.html">Réservation</a></li>
				<li><a href="membre.php">Espace membre</a></li>
				<li><a href="deconnexion.php">Deconnexion</a></li>
				<!-- <li><a href="php/connexion.php">Connexion</a></li> -->
			</ul>
		</nav>
	</header>
	<br><br><br><br><br><br><br>
	<center><div>
		<table>
			<tr>
				<th>Cours Proposés</th>
				<th>Cours Demandés</th>
			</tr>
			<tr>
				<td>
					<form method="POST" action="courProf.php">
					<?php
						try
						{
							// On se connecte à MySQL
							$bdd = new PDO('mysql:host=localhost;dbname=teachu;charset=utf8', 'root', '');
						}
						catch(Exception $e)
						{
							// En cas d'erreur, on affiche un message et on arrête tout
						        die('Erreur : '.$e->getMessage());
						}

						// Si tout va bien, on peut continuer

						// On récupère tout le contenu de la table jeux_video
						$reponse = $bdd->query('SELECT * FROM courprof');

						// On affiche chaque entrée une à une
						while ($donnees = $reponse->fetch())
						{
						?>
						    <p>
						    <strong>Professeur : </strong><?php echo $donnees['nomProf']; ?><br>
						    <strong>Adresse Mail du Professeur : </strong><?php echo $donnees['emailProf']; ?><br>
						    <strong>Compétence : </strong><?php echo $donnees['matiereProf']; ?><br>
						    <strong>Date du Cour : </strong><?php echo $donnees['dateProf']; ?><br>
						    <strong>Lieu du Cour : </strong><?php echo $donnees['lieuProf']; ?><br>
						    <strong>Heure du Cour : </strong><?php echo $donnees['heureProf']; ?><br><br>
						   </p>
						<?php
						}

						$reponse->closeCursor(); // Termine le traitement de la requête

						?>
					</td>
					<td>
						<form method="POST" action="courEtud.php">
						<?php
						try
						{
							// On se connecte à MySQL
							$bdd = new PDO('mysql:host=localhost;dbname=teachu;charset=utf8', 'root', '');
						}
						catch(Exception $e)
						{
							// En cas d'erreur, on affiche un message et on arrête tout
						        die('Erreur : '.$e->getMessage());
						}

						// Si tout va bien, on peut continuer

						// On récupère tout le contenu de la table jeux_video
						$reponse = $bdd->query('SELECT * FROM cours');

						// On affiche chaque entrée une à une
						while ($donnees = $reponse->fetch())
						{
						?>
						    <p>
						    <strong>Elève : </strong><?php echo $donnees['nomEtudiant']; ?><br>
						    <strong>Adresse Mail de l'Etudiant : </strong><?php echo $donnees['emailEtud']; ?><br>
						    <strong>Compétence : </strong><?php echo $donnees['matiereEtud']; ?><br>
						    <strong>Date du Cour : </strong><?php echo $donnees['dateEtud']; ?><br>
						    <strong>Lieu du Cour : </strong><?php echo $donnees['lieuEtud']; ?><br>
						    <strong>Heure du Cour : </strong><?php echo $donnees['heureEtud']; ?><br><br>
						   </p>
						<?php
						}

						$reponse->closeCursor(); // Termine le traitement de la requête

						?>
					</td>
			</tr>
		</table>
	</form>
</div>
</center>

</body>
</html>