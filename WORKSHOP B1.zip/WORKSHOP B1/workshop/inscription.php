<?php

include("PDO.php");

$bdd = getDatabase();
 
    if((!empty($_POST['nom'])) AND (!empty($_POST['prenom'])) AND (!empty($_POST['email'])) AND (!empty($_POST['password'])) AND (!empty($_POST['telephone'])) AND (!empty($_POST['ville'])))
    {
    $req = $bdd->prepare('SELECT id from etudiants where email = :email');


$tab = array(
':nom' => $_POST['nom'],
':prenom' => $_POST['prenom'],
':email' => $_POST['email'],
':password' => $_POST['password'],
':telephone' => $_POST['telephone'],
':ville' => $_POST['ville']);

//création de la requête insert
$req = $bdd->prepare ('INSERT INTO etudiants(nom, prenom, email, password, telephone, ville)
        VALUES( :nom, :prenom, :email, :password, :telephone, :ville)');

    $req->bindValue(':nom',$_POST['nom'],PDO::PARAM_STR);
    $req->bindValue(':prenom',$_POST['prenom'],PDO::PARAM_STR);
    $req->bindValue(':email',$_POST['email'],PDO::PARAM_STR);
    $req->bindValue(':password',$_POST['password'],PDO::PARAM_STR);
    $req->bindValue(':telephone',$_POST['telephone'],PDO::PARAM_STR);
    $req->bindValue(':ville',$_POST['ville'],PDO::PARAM_STR);

if ($req->execute($tab)) {
echo '<center><h3>Insertion effectuée !</h3></center>'.'<center><h1><a href="homeTest.html">Retour</a></h1></center>';
} 
else {
echo 'Erreur d\'insertion : l\'insertion n\'est pas effective';
}

// fermeture connexion
if($bdd) {
    $bdd = NULL;
    }
}
?>