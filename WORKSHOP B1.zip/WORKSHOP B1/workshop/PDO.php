<?php

function getDataBase()
{
   $host = "localhost";  
   $dbName = "teachu";
   // Ex : $dbName = "neptune";
   $login = "root";
   $password = "";

    try
    {
        // Création de l’objet $bdd de type Pdo avec affichage des erreurs
        $bdd = new PDO('mysql:host='.$host.';dbname='.$dbName.';charset=utf8', $login, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    }
    catch (Exception $e)
    {
        $bdd = null;
        die('Erreur : ' . $e->getMessage());
    }
    
    // retourne l’objet de type Pdo
    return $bdd;
}
