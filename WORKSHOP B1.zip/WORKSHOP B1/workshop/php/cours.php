<?php

include("PDO.php");

$bdd = getDatabase();

if((isset($_POST['id'])) and (isset($_POST['name'])) and (isset($_POST['email'])) and (isset($_POST['lieu']))and (isset($_POST['matiere']))and (isset($_POST['comment']))and (isset($_POST['date']))) {

	$req = $bdd->prepare('INSERT INTO cours (id, name, email, lieu, matiere, comment, date) VALUES(:id, :name, :email, :lieu, :matiere, :comment, :date)');

	$req->bindValue(':id', $_POST['id'], PDO::PARAM_INT);
	$req->bindValue(':nom', $_POST['name'], PDO::PARAM_STR);
	$req->bindValue(':prenom', $_POST['email'], PDO::PARAM_STR);
	$req->bindValue(':id', $_POST['lieu'], PDO::PARAM_STR);
	$req->bindValue(':nom', $_POST['matiere'], PDO::PARAM_STR);
	$req->bindValue(':prenom', $_POST['comment'], PDO::PARAM_STR);
	$req->bindValue(':prenom', $_POST['date'], PDO::PARAM_STR);

	if ($req->execute()){
		echo 'Cours enregistré';
	} else {
		echo 'Veuillez remplir tous les champs';
	}
	$req->closeCursor();
	header('Location: services.html');
	}

?>