<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Connection</title>
</head>
 
<body class="fond">
 
 
 
<?php
include ("PDO.php");
 
if (isset($_SESSION['email']))
{
    echo" Vous êtes déjà connecté";
 
}
 
 
else
{
    if (isset($_POST['email']) AND isset($_POST['password']))
    {
 
        $bdd = getDataBase();
 
 
        // Vérification des identifiants
 
 
        $req = $bdd->prepare('SELECT id FROM etudiants WHERE email = :email AND password = :password');
        $req->execute(array(
            'email' => $_POST['email'],
            'password' => $_POST['password']));
 
        $resultat = $req->fetch();
 
 
        if (!$resultat)
        {
            echo 'identifiant ou mot de passe incorect !';
        }
        else
        {
            $_SESSION['email'] = $_POST['email'];
            header('location: ../homeConnect.html');
            echo 'Vous êtes connecté !';
            session_start();
        }
    }
 
    else
 
 
    {
        ?>
        <!-- DEBUT FORMULAIRE CONNEXION  -->
 
        <div>
            <form method="post">
 
                <div class="form-group">
                    <label >Adresse Email</label>
                    <input type="email" name="email" class="form-control"
                           aria-describedby="emailHelp"
                           placeholder="Entrez votre email">
                </div>
 
                <div class="form-group">
                    <label for="exampleInputPassword1" >Mot de passe</label>
                    <input type="password" class="form-control" name="password"
                           placeholder="Mot de passe">
                </div>
 
                <button type="submit" class="btn btn-primary">Soumettre</button>
            </form>
        </div>
        <!-- FIN FORMULAIRE CONNEXION -->
 
        <p>Vous n'etes pas encore inscrit? Inscrivez vous <a href="inscriptionC.php">ici</a></p>
 
 
        <?php
    }
 
}
?>
</body>
</html>