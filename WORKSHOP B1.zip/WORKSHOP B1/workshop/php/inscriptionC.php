<?php

include("PDO.php");

$bdd = getDatabase();

	if((!empty($_POST['nom'])) AND (!empty($_POST['prenom'])) AND (!empty($_POST['email'])) AND (!empty($_POST['password'])) AND (!empty($_POST['telephone'])) AND (!empty($_POST['ville'])))
	{
	$req = $bdd->prepare('SELECT id from etudiants where email = :email');


 // nom = :nom, prenom = :nom, email =:email, password = :password, telephone = :telephone, dispo = :dispo, ville = :ville
	// $req->bindValue(':nom',$_POST['nom'],PDO::PARAM_STR);
	// $req->bindValue(':prenom',$_POST['prenom'],PDO::PARAM_STR);
	$req->bindValue(':email',$_POST['email'],PDO::PARAM_STR);
	// $req->bindValue(':password',$_POST['password'],PDO::PARAM_STR);
	// $req->bindValue(':telephone',$_POST['telephone'],PDO::PARAM_INT);
	// $req->bindValue(':dispo',$_POST['dispo'],PDO::PARAM_STR);
	// $req->bindValue(':ville',$_POST['ville'],PDO::PARAM_STR);
	$req->execute();
	$check=$req->fetch();

	if ($check)
	{

	echo'Utilisateur deja pris';
	}
	else
	{

    $req = $bdd->prepare('INSERT INTO etudiants(nom, prenom, email, password, telephone, dispo, ville)
	VALUES(:nom, :prenom, :email, :password, :telephone, :dispo, :ville)');
	$req->bindValue(':nom',$_POST['nom'],PDO::PARAM_STR);
	$req->bindValue(':prenom',$_POST['prenom'],PDO::PARAM_STR);
	$req->bindValue(':email',$_POST['email'],PDO::PARAM_STR);
	$req->bindValue(':password',$_POST['password'],PDO::PARAM_STR);
	$req->bindValue(':telephone',$_POST['telephone'],PDO::PARAM_INT);
	$req->bindValue(':dispo',$_POST['dispo'],PDO::PARAM_STR);
	$req->bindValue(':ville',$_POST['ville'],PDO::PARAM_STR);
	
	//$req->bindValue(':date_inscrip', $_POST['date_inscrip'], PDO::PARAM_STR);

	if ($req->execute()){
	echo 'Enregistrement réussi ! vous pouvez vous <a href="connexionC.php">Connecter</a>';
	}
	else
	{
	echo 'Erreur system';
	}
	$req->closeCursor();
	}
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Bootstrap/docs/favicon.ico">
    <link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,700|Roboto:300,400,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="./css/bootstrap.min.css"/>
	<link rel="stylesheet" href="./css/font-awesome.min.css"/>
	<link rel="stylesheet" href="./css/flaticon.css"/>
	<link rel="stylesheet" href="./css/magnific-popup.css"/>
	<link rel="stylesheet" href="./css/owl.carousel.css"/>
	<link rel="stylesheet" href="./css/style.css"/>

	<!-- Bootstrap core CSS -->
    <link href="Bootstrap/dist/css/bootstrap.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="Bootstrap/docs/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="Bootstrap/docs/assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <title>Connexion</title>

  </head>

  <body>

  	<div id="preloder">
		<div class="loader">
			<img src="img/logo.png" alt="">
			<h2>Loading.....</h2>
		</div>
	</div>


	<!-- Header section -->
	<header class="header-section">
		<div class="logo">
			<img src="img/logo.png" alt=""><!-- Logo -->
		</div>
		<!-- Navigation -->
		<div class="responsive"><i class="fa fa-bars"></i></div>
		<nav>
			<ul class="menu-list">
				<li class="active"><a href="home.html">Home</a></li>
				<li><a href="services.html">Services</a></li>
				<li><a href="blog.html">Blog</a></li>
				<li><a href="php/InscriptionC.php">Inscription</a></li>
				<li><a href="php/ConnexionC.php">Elements</a></li>
			</ul>
		</nav>
	</header>
	<!-- Header section end -->
<h1>Inscription</h1>
<form method="POST" action="inscriptionC.php">
<!--

<SELECT name = "civil">
<OPTION value = "Monsieur">Monsieur</OPTION>
<OPTION value = "Madame">Madame</OPTION>
</SELECT><br/><br/>
<input type="text" name="nom" placeholder="Nom"><br/><br/>
<input type="text" name="prenom" placeholder="Prenom"><br/><br/>
<input type="text" name="adresse" placeholder="Adresse"><br/><br/>
<input type="text" name="codePostal" placeholder="Code postal"><br/><br/>
<input type="text" name="ville" placeholder="Ville"><br/><br/>
<input type="text" name="pays" placeholder="Pays"><br/><br/>
<input type="text" name="pseudo" placeholder="Pseudo"><br/><br/>

 -->
<label for="inputNom" class="sr-only">Nom</label>
<input type="nom" id="inputNom" name="nom"  class="form-control" placeholder="Nom" required autofocus>
<br>
<label for="inputPrenom" class="sr-only">Prénom</label>
<input type="prenom" id="inputPrenom" name="prenom"  class="form-control" placeholder="Prénom" required autofocus>
<br>
<label for="inputEmail" class="sr-only">Adresse E-mail</label>
<input type="email" id="inputEmail" name="email"  class="form-control" placeholder="Email address" required autofocus>
<br>
<label for="inputPassword" class="sr-only">Password</label>
<input type="password" name="password"  id="inputPassword" class="form-control" placeholder="Mot de passe" required>
<br>
<label for="inputNom" class="sr-only">Teléphone</label>
<input type="telephone" id="inputTelephone" name="telephone"  class="form-control" placeholder="Teléphone" required autofocus>
<br>
<label for="inputNom" class="sr-only">dispo</label>
<input type="dispo" id="inputDispo" name="dispo"  class="form-control" placeholder="disponibilité" required autofocus>
<br>
<label for="inputVille" class="sr-only">Ville</label>
<input type="ville" id="inputVille" name="ville"  class="form-control" placeholder="Ville" required autofocus>
<br>

<input type="submit" value="Inscription"/>

<!-- Footer section -->
	<footer class="footer-section">
		<h2>2018 All rights reserved. Designed by <a href="https://colorlib.com" target="_blank">Epsi</a></h2>
	</footer>
	<!-- Footer section end -->




	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>

</form>
</body>
</html>
