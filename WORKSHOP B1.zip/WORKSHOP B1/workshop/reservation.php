<?php

include("PDO.php");

$bdd = getDatabase();
 
    if((!empty($_POST['nomProf'])) AND (!empty($_POST['nomEtud'])) AND (!empty($_POST['date'])) AND (!empty($_POST['lieu'])) AND (!empty($_POST['competence'])) AND (!empty($_POST['heure'])))
    {
    $req = $bdd->prepare('SELECT id FROM reservation ');


$tab = array(
':nomProf' => $_POST['nomProf'],
':nomEtud' => $_POST['nomEtud'],
':date' => $_POST['date'],
':lieu' => $_POST['lieu'],
':competence' => $_POST['competence'],
':heure' => $_POST['heure']);

//création de la requête insert
$req = $bdd->prepare ('INSERT INTO reservation(nomProf, nomEtud, date, lieu, competence, heure)
		VALUES( :nomProf, :nomEtud, :date, :lieu, :competence, :heure)');

    $req->bindValue(':nomProf',$_POST['nomProf'],PDO::PARAM_STR);
    $req->bindValue(':nomEtud',$_POST['nomEtud'],PDO::PARAM_STR);
    $req->bindValue(':date',$_POST['date'],PDO::PARAM_STR);
    $req->bindValue(':lieu',$_POST['lieu'],PDO::PARAM_STR);
    $req->bindValue(':competence',$_POST['competence'],PDO::PARAM_STR);
    $req->bindValue(':heure',$_POST['heure'],PDO::PARAM_STR);

if ($req->execute($tab)) {
echo '<center><h3>Insertion effectuée !</h3></center>'.'<center><h1><a href="formulaire.html">Retour</a></h1></center>';
} 
else {
echo 'Erreur d\'insertion : l\'insertion n\'est pas effective';
}

// fermeture connexion
if($bdd) {
    $bdd = NULL;
	}
}
?>
