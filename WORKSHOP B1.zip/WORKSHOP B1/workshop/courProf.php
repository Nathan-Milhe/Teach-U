<?php

include("PDO.php");

$bdd = getDatabase();
 
    if((!empty($_POST['dateProf'])) AND (!empty($_POST['lieuProf'])) AND (!empty($_POST['emailProf'])) AND (!empty($_POST['nomProf'])) AND (!empty($_POST['matiereProf'])) AND (!empty($_POST['heureProf'])))
    {
    $req = $bdd->prepare('SELECT idProf from courprof where emailProf = :emailProf');


$tab = array(
':dateProf' => $_POST['dateProf'],
':lieuProf' => $_POST['lieuProf'],
':emailProf' => $_POST['emailProf'],
':nomProf' => $_POST['nomProf'],
':matiereProf' => $_POST['matiereProf'],
':heureProf' => $_POST['heureProf']);

//création de la requête insert
$req = $bdd->prepare ('INSERT INTO courprof(dateProf, lieuProf, emailProf, nomProf, matiereProf, heureProf)
        VALUES( :dateProf, :lieuProf, :emailProf, :nomProf, :matiereProf, :heureProf)');

    $req->bindValue(':dateProf',$_POST['dateProf'],PDO::PARAM_STR);
    $req->bindValue(':lieuProf',$_POST['lieuProf'],PDO::PARAM_STR);
    $req->bindValue(':emailProf',$_POST['emailProf'],PDO::PARAM_STR);
    $req->bindValue(':nomProf',$_POST['nomProf'],PDO::PARAM_STR);
    $req->bindValue(':matiereProf',$_POST['matiereProf'],PDO::PARAM_STR);
    $req->bindValue(':heureProf',$_POST['heureProf'],PDO::PARAM_STR);

if ($req->execute($tab)) {
echo '<center><h3>Insertion effectuée !</h3></center>'.'<center><h1><a href="cours.php">Retour</a></h1></center>';
} 
else {
echo 'Erreur d\'insertion : l\'insertion n\'est pas effective';
}

// fermeture connexion
if($bdd) {
    $bdd = NULL;
    }
}
?>