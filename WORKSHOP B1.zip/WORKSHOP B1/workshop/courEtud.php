<?php

include("PDO.php");

$bdd = getDatabase();
 
    if((!empty($_POST['dateEtud'])) AND (!empty($_POST['lieuEtud'])) AND (!empty($_POST['emailEtud'])) AND (!empty($_POST['nomEtudiant'])) AND (!empty($_POST['matiereEtud'])) AND (!empty($_POST['heureEtud'])))
    {
    $req = $bdd->prepare('SELECT id from cours where emailEtud = :emailEtud');


$tab = array(
':dateEtud' => $_POST['dateEtud'],
':lieuEtud' => $_POST['lieuEtud'],
':emailEtud' => $_POST['emailEtud'],
':nomEtudiant' => $_POST['nomEtudiant'],
':matiereEtud' => $_POST['matiereEtud'],
':heureEtud' => $_POST['heureEtud']);

//création de la requête insert
$req = $bdd->prepare ('INSERT INTO cours(dateEtud, lieuEtud, emailEtud, nomEtudiant, matiereEtud, heureEtud)
        VALUES( :dateEtud, :lieuEtud, :emailEtud, :nomEtudiant, :matiereEtud, :heureEtud)');

    $req->bindValue(':dateEtud',$_POST['dateEtud'],PDO::PARAM_STR);
    $req->bindValue(':lieuEtud',$_POST['lieuEtud'],PDO::PARAM_STR);
    $req->bindValue(':emailEtud',$_POST['emailEtud'],PDO::PARAM_STR);
    $req->bindValue(':nomEtudiant',$_POST['nomEtudiant'],PDO::PARAM_STR);
    $req->bindValue(':matiereEtud',$_POST['matiereEtud'],PDO::PARAM_STR);
    $req->bindValue(':heureEtud',$_POST['heureEtud'],PDO::PARAM_STR);

if ($req->execute($tab)) {
echo '<center><h3>Insertion effectuée !</h3></center>'.'<center><h1><a href="cours.php">Retour</a></h1></center>';
} 
else {
echo 'Erreur d\'insertion : l\'insertion n\'est pas effective';
}

// fermeture connexion
if($bdd) {
    $bdd = NULL;
    }
}
?>