<?php

include("php/PDO.php");

$bdd = getDatabase();

	if((!empty($_POST['matiere'])) AND (!empty($_POST['niveau'])))
	{
	$req = $bdd->prepare('SELECT id from competences where id = :id');


 // nom = :nom, prenom = :nom, email =:email, password = :password, telephone = :telephone, dispo = :dispo, ville = :ville
	// $req->bindValue(':nom',$_POST['nom'],PDO::PARAM_STR);
	// $req->bindValue(':prenom',$_POST['prenom'],PDO::PARAM_STR);
	$req->bindValue(':id',$_POST['id'],PDO::PARAM_INT);
	// $req->bindValue(':password',$_POST['password'],PDO::PARAM_STR);
	// $req->bindValue(':telephone',$_POST['telephone'],PDO::PARAM_INT);
	// $req->bindValue(':dispo',$_POST['dispo'],PDO::PARAM_STR);
	// $req->bindValue(':ville',$_POST['ville'],PDO::PARAM_STR);
	$req->execute();
	$check=$req->fetch();

	if ($check)
	{

	echo'Utilisateur deja pris';
	}
	else
	{

    $req = $bdd->prepare('INSERT INTO competences(matiere, niveau)
	VALUES(:matiere, :niveau)');
	$req->bindValue(':matiere',$_POST['matiere'],PDO::PARAM_STR);
	$req->bindValue(':niveau',$_POST['niveau'],PDO::PARAM_INT);
	
	//$req->bindValue(':date_inscrip', $_POST['date_inscrip'], PDO::PARAM_STR);

	if ($req->execute()){
	echo 'Enregistrement réussi ! Vous pouvez vous <a href="connexionC.php">Connecter</a>';
	}
	else
	{
	echo 'Erreur system';
	}
	$req->closeCursor();
	}
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Bootstrap/docs/favicon.ico">
    <link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,700|Roboto:300,400,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="./css/bootstrap.min.css"/>
	<link rel="stylesheet" href="./css/font-awesome.min.css"/>
	<link rel="stylesheet" href="./css/flaticon.css"/>
	<link rel="stylesheet" href="./css/magnific-popup.css"/>
	<link rel="stylesheet" href="./css/owl.carousel.css"/>
	<link rel="stylesheet" href="./css/style.css"/>


    <title>Connexion</title>

    <!-- Bootstrap core CSS -->
    <link href="Bootstrap/dist/css/bootstrap.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="Bootstrap/docs/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="Bootstrap/docs/assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
  	<!-- Header section -->
	<header class="header-section">
		<div class="logo">
			<img src="logo/logo.png" alt=""><!-- Logo -->
		</div>
		<!-- Navigation -->
		<div class="responsive"><i class="fa fa-bars"></i></div>
		<nav>
			<ul class="menu-list">
				<li><a href="homeConnect.html">Home</a></li>
				<li><a href="annonce.php">Annonces</a></li>
				<li><a href="cours.php">Cours</a></li>
				<li><a href="formulaire.html">Réservation</a></li>
				<li class="active"><a href="membre.php">Espace membre</a></li>
				<li><a href="deconnexion.php">Deconnexion</a></li>
				<!-- <li><a href="php/connexion.php">Connexion</a></li> -->
			</ul>
		</nav>
	</header><br><br><br><br><br><br>
  	<center>
<h1>Fiche de compétences</h1><br><br>
<form method="POST" action="competences.php">

		<div>
			<p>Vos Compétences :</p>
			<select class="selection-2" name="budget" id="matiere">
				<option selected="active">Aucune</option>
				<option value="fr">Français</option>
				<option value="droit">Droit</option>
				<option value="maths">Maths</option>
				<option value="anglais">Anglais</option>
				<option value="php">PHP</option>
				<option value="html">HTML/CSS</option>
				<option value="js">JS</option>
				<option value="bdd">BDD</option>
				<option value="c">C#</option>
				<option value="java">Java</option>
				<option value="reseau">Reseau</option>
				<option value="linux">Linux</option>
			</select>
		</div>
<br>
<p>Votre niveau dans cette compétence :</p>
<label for="inputNiveau" class="sr-only"></label>
<input type="niveau" id="inputNiveau" name="niveau" placeholder="ex : 4/5" required >
<br>
</form>
<br>
<input type="submit" value="Ajouter"/>
<br>
<hr>
<br>
<form method="GET" action="reservation.php">
	<div>
		<table>
			<tr>
				<th>Cours à Venir : </th>
			</tr><br>
			<tr>
				<td>
					<form method="POST" action="reservation.php">
					<?php
						try
						{
							// On se connecte à MySQL
							$bdd = new PDO('mysql:host=localhost;dbname=teachu;charset=utf8', 'root', '');
						}
						catch(Exception $e)
						{
							// En cas d'erreur, on affiche un message et on arrête tout
						        die('Erreur : '.$e->getMessage());
						}

						// Si tout va bien, on peut continuer

						// On récupère tout le contenu de la table jeux_video
						$reponse = $bdd->query('SELECT * FROM reservation');

						// On affiche chaque entrée une à une
						while ($donnees = $reponse->fetch())
						{
						?>
						    <p>
						    <strong>Professeur : </strong><?php echo $donnees['nomProf']; ?><br>
						    <strong>Vous : </strong><?php echo $donnees['nomEtud']; ?><br>
						    <strong>Compétence : </strong><?php echo $donnees['competence']; ?><br>
						    <strong>Date du Cour : </strong><?php echo $donnees['date']; ?><br>
						    <strong>Lieu du Cour : </strong><?php echo $donnees['lieu']; ?><br>
						    <strong>Heure du Cour : </strong><?php echo $donnees['heure']; ?><br><br>
						   </p>
						<?php
						}

						$reponse->closeCursor(); // Termine le traitement de la requête

						?>
				</td>
			</tr>
		</table>
	</div>
</form>
</center>
</body>
</html>
