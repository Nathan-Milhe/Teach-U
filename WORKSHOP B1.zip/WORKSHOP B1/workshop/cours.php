<!DOCTYPE html>
<html lang="en">
<head>
	<title>Labs - Design Studio</title>
	<meta charset="UTF-8">
	<meta name="description" content="Labs - Design Studio">
	<meta name="keywords" content="lab, onepage, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,700|Roboto:300,400,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader">
			<img src="logo/logo.png" alt="">
			<h2>Loading.....</h2>
		</div>
	</div>


	<!-- Header section -->
	<header class="header-section">
		<div class="logo">
			<img src="logo/logo.png" alt=""><!-- Logo -->
		</div>
		<!-- Navigation -->
		<div class="responsive"><i class="fa fa-bars"></i></div>
		<nav>
			<ul class="menu-list">
				<li><a href="home.html">Home</a></li>
				<li><a href="annonce.php">Annonces</a></li>
				<li class="active"><a href="cours.php">Cours</a></li>
				<li><a href="formulaire.html">Réservation</a></li>
				<li><a href="membre.php">Espace membre</a></li>
				<li><a href="deconnexion.php">Deconnexion</a></li>

				<!-- <li><a href="php/connexion.php">Connexion</a></li> -->
			</ul>
		</nav>
	</header>
	<!-- Header section end --><br><br><br><br><br><br><br>

	<center><p>Proposer un Cour :</p></center>
			<form name="insertion" action="courProf.php" method="POST">
				<table border="0" align="center" cellspacing="2" cellpadding="2">
					<tr align="center">
						<td id="TdBlur">Date du Cour</td>
						<td><input type="date" name="dateProf" class="textbox"></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Lieu</td>
						<td><input type="text" name="lieuProf" class="textbox"></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Votre email</td>
						<td><input type="text" name="emailProf" class="mail"></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Votre Nom</td>
						<td><center><input type="text" name="nomProf" class="textbox"></center></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Compétence Désirée</td>
						<td><center><input type="text" name="matiereProf" class="textbox"></center></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Heure souhaité</td>
						<td><center><input type="time" name="heureProf" class="textbox"></center></td>
					</tr>
					<tr align="center">
						<td colspan="2"><input type="submit" value="insérer" class="myButton"></td>
					</tr>


				</table>
		</form><br><br>

		<center><p>Demander un Cour :</p></center>
			<form name="insertion" action="courEtud.php" method="POST">
				<table border="0" align="center" cellspacing="2" cellpadding="2">
					<tr align="center">
						<td id="TdBlur">Date du Cour</td>
						<td><input type="date" name="dateEtud" class="textbox"></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Lieu</td>
						<td><input type="text" name="lieuEtud" class="textbox"></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Votre email</td>
						<td><input type="text" name="emailEtud" class="email"></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Votre Nom</td>
						<td><center><input type="text" name="nomEtudiant" class="textbox"></center></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Compétence Désirée</td>
						<td><center><input type="text" name="matiereEtud" class="textbox"></center></td>
					</tr>
					<tr align="center">
						<td id="TdBlur">Heure souhaité</td>
						<td><center><input type="time" name="heureEtud" class="textbox"></center></td>
					</tr>
					<tr align="center">
						<td colspan="2"><input type="submit" value="insérer" class="myButton"></td>
					</tr>
				</table>
		</form><br><br><br>
		<center><a href="homeConnect.html">Retour</a></center><br>



		<!-- Footer section -->
	<footer class="footer-section">
		<p>2018 Tout Droits Réservés | EPSI de Montpellier | Workshop</p>
	</footer>
	<!-- Footer section end -->




	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>
</body>
</html>